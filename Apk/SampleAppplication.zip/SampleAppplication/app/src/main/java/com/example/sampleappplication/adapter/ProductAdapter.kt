package com.example.sampleappplication.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.sampleappplication.R
import com.example.sampleappplication.model.ProductResponse

class ProductAdapter(val productResponse: ProductResponse) : RecyclerView.Adapter<ProductAdapter.ViewHolder>() {

    var onItemClick: ((position: Int) -> Unit)? = null
    private var onProductAdded: OnProductAdded?= null
    val productHashMap =  HashMap<Int,Int>()

    // create new views
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // inflates the card_view_design view
        // that is used to hold list item
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.layout_list, parent, false)

        return ViewHolder(view)
    }

    // binds the list items to a view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        var count = 0
        holder.btnCount.text = count.toString()
        if (productResponse[position].count == null) {
            count = 0
            holder.btnCount.text = count.toString()
        }
        else {
            count = productResponse[position].count.toInt()
            holder.btnCount.text = productResponse[position].count
        }
        holder.btnAdd.setOnClickListener {
            count += 1
            holder.btnCount.text = count.toString()
            productHashMap[position] = count
            onProductAdded?.productAdded(productHashMap)
        }
        holder.btnRemove.setOnClickListener {
            if (count > 0) {
                count -= 1
            }
            holder.btnCount.text = count.toString()
            productHashMap[position] = count
            onProductAdded?.productRemoved(productHashMap)
        }
        Glide.with(holder.itemView.context).load(productResponse[position].image).into(holder.imgProduct)
        holder.txtProductName.text = productResponse[position].title
        holder.txtProductPrice.text = holder.itemView.context.getString(R.string.rs) + productResponse[position].price.toString()
        holder.txtProductCategory.text = productResponse[position].category

    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return productResponse.size
    }

    // Holds the views for adding it to image and text
    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val cardBack: CardView = itemView.findViewById(R.id.card_back)
        val imgProduct: ImageView = itemView.findViewById(R.id.img_product)
        val txtProductName: TextView = itemView.findViewById(R.id.txt_product_name)
        val txtProductPrice: TextView = itemView.findViewById(R.id.txt_product_price)
        val txtProductCategory: TextView = itemView.findViewById(R.id.txt_product_category)
        val btnAdd: Button = itemView.findViewById(R.id.btn_add)
        val btnRemove: Button = itemView.findViewById(R.id.btn_remove)
        val btnCount: Button = itemView.findViewById(R.id.btn_count)
    }

    fun setOnProductAdded (listener: OnProductAdded){
        onProductAdded = listener
    }

    interface OnProductAdded {
        fun productAdded(productHashMap: HashMap<Int, Int>)
        fun productRemoved(productHashMap: HashMap<Int, Int>)
    }
}