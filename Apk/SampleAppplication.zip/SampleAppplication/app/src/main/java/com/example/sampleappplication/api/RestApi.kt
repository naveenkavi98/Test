package com.example.sampleappplication.api

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RestApi {

    companion object {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://fakestoreapi.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiInterface::class.java)
    }

}