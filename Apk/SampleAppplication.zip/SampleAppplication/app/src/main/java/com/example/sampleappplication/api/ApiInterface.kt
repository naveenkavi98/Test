package com.example.sampleappplication.api


import com.example.sampleappplication.model.ProductResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiInterface {
    @GET("products")
    fun callApi(): Call<ProductResponse>
}