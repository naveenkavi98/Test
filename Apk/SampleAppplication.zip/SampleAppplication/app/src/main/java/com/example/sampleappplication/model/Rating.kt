package com.example.sampleappplication.model

data class Rating(
    val count: Int,
    val rate: Double
)