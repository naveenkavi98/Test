package com.example.sampleappplication.model

class ProductResponse : ArrayList<ProductResponseItem>()