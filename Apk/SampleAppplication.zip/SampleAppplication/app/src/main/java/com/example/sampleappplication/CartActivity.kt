package com.example.sampleappplication

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.sampleappplication.adapter.ProductAdapter
import com.example.sampleappplication.databinding.ActivityCartBinding
import com.example.sampleappplication.model.ProductResponse
import com.google.gson.Gson
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject


class CartActivity : AppCompatActivity() {
    lateinit var binding: ActivityCartBinding
    var totalPrice : Double = 0.0
    var dataHashMap = HashMap<Int,Int>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCartBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initView()
    }

    private fun initView() {
        val price = intent.getStringExtra("PRICE")
        val data = Gson().fromJson(intent.getStringExtra("RESPONSE"),ProductResponse ::class.java)
        binding.txtProductTotalPrice.text= price
        val productAdapter = data?.let { ProductAdapter(it) }
        binding.rcvProduct.adapter = productAdapter
        productAdapter?.setOnProductAdded(object  :  ProductAdapter.OnProductAdded{
            override fun productAdded(productHashMap: HashMap<Int, Int>) {
                totalPrice = 0.0
                binding.lnrCart.visibility = View.VISIBLE
                Log.e( "productAdded: ", "$productHashMap")
                dataHashMap = productHashMap
                for(key in productHashMap.keys){
                    val price = data[key].price
                    val itemCount = productHashMap[key]
                    data[key].count = itemCount.toString()
                    val amount = price* itemCount!!
                    totalPrice = (totalPrice + amount).toDouble()
                    binding.txtProductTotalPrice.text = resources.getString(R.string.rs) +  String.format("%.2f",totalPrice)
                    Log.e( "productTotalPrice: ", "$totalPrice")
                }
            }

            override fun productRemoved(productHashMap: HashMap<Int, Int>) {
                totalPrice = 0.0
                Log.e( "productAdded: ", "$productHashMap")
                dataHashMap = productHashMap
                for(key in productHashMap.keys){
                    val price = data[key].price
                    val itemCount = productHashMap[key]
                    val amount = price* itemCount!!
                    totalPrice = (totalPrice + amount).toDouble()
                    binding.txtProductTotalPrice.text =resources.getString(R.string.rs) +  String.format("%.2f",totalPrice)
                    Log.e( "productTotalPrice: ", "$totalPrice")
                }
            }

        })

        binding.txtBack.setOnClickListener {
            finish()
        }
    }
}