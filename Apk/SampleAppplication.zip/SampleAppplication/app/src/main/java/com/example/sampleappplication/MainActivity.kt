package com.example.sampleappplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import com.example.sampleappplication.adapter.ProductAdapter
import com.example.sampleappplication.api.RestApi
import com.example.sampleappplication.databinding.ActivityMainBinding
import com.example.sampleappplication.model.ProductResponse
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    lateinit var bottomSheetDialog: BottomSheetDialog
    var totalPrice : Double = 0.0
    var data= ProductResponse()
    var dataHashMap = HashMap<Int,Int>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initView()
    }

    private fun initView() {
        callApi()
        binding.txtViewCart.setOnClickListener {
            val intent = Intent(this@MainActivity, CartActivity :: class.java)
            intent.putExtra("RESPONSE", Gson().toJson(data).toString())
            intent.putExtra("PRICE",binding.txtProductTotalPrice.text.toString())
            startActivity(intent)
        }

    }

    fun callApi() {
        RestApi.retrofit.callApi().enqueue(object :
            Callback<ProductResponse> {
            override fun onResponse(call: Call<ProductResponse>, response: Response<ProductResponse>) {
                Log.e( "onResponse: ", "$response")
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        data = responseBody
                    }
                    val productAdapter = responseBody?.let { ProductAdapter(it) }
                    binding.rcvProduct.adapter = productAdapter
                    productAdapter?.setOnProductAdded(object  :  ProductAdapter.OnProductAdded{
                        override fun productAdded(productHashMap: HashMap<Int, Int>) {
                            totalPrice = 0.0
                            binding.lnrCart.visibility = View.VISIBLE
                            Log.e( "productAdded: ", "$productHashMap")
                            dataHashMap = productHashMap
                            for(key in productHashMap.keys){
                                val price = responseBody[key].price
                                val itemCount = productHashMap[key]
                                data[key].count = itemCount.toString()
                                val amount = price* itemCount!!
                                totalPrice = (totalPrice + amount).toDouble()
                                binding.txtProductTotalPrice.text = resources.getString(R.string.rs) +  String.format("%.2f",totalPrice)
                                Log.e( "productTotalPrice: ", "$totalPrice")
                            }
                        }

                        override fun productRemoved(productHashMap: HashMap<Int, Int>) {
                            totalPrice = 0.0
                            Log.e( "productAdded: ", "$productHashMap")
                            dataHashMap = productHashMap
                            for(key in productHashMap.keys){
                                val price = responseBody[key].price
                                val itemCount = productHashMap[key]
                                val amount = price* itemCount!!
                                totalPrice = (totalPrice + amount).toDouble()
                                binding.txtProductTotalPrice.text =resources.getString(R.string.rs) +  String.format("%.2f",totalPrice)
                                Log.e( "productTotalPrice: ", "$totalPrice")
                            }
                        }

                    })
                }
            }

            override fun onFailure(call: Call<ProductResponse>, t: Throwable) {
                Log.e( "onFailure: ", "$t")
            }
        })
    }

}